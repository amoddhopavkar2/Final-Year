package com.learn;

public class Demo {

public String display() {
    return "Welcome to web service";
}

public int addition (int a, int b, int c {
    return a+b+c;
}

public String setName() {
    String name = "Hi Amod!";
    return name;
}

}